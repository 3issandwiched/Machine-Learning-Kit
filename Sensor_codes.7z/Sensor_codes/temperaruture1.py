import time
import Adafruit_GPIO.SPI as SPI
import Adafruit_MAX6675.MAX6675 as MAX6675

# Define the SPI configuration
SPI_PORT = 0
SPI_DEVICE = 0

# Initialize the MAX6675 sensor
sensor = MAX6675.MAX6675(spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE))

try:
    while True:
        # Read temperature in Celsius
        temperature = sensor.readTempC()
        print(f"Temperature: {temperature} °C")
        time.sleep(1)

except KeyboardInterrupt:
    print("Temperature reading stopped")
