
from gpiozero import MCP3008
import time

# Create instances of MCP3008 with the appropriate GPIO pins for channel 0 and channel 1
mcp3008_channel0 = MCP3008(channel=3, max_voltage=5.0)
#mcp3008_channel1 = MCP3008(channel=1, max_voltage=5.0)
#R1 = 30000.0;
#R2 = 7500.0; 
while True:
    # Read the analog values from channel 0 and channel 1
    sum_=0
    for i in range(0,5000):
        analog_value_channel0 = mcp3008_channel0.value
        #analog_value_channel1 = mcp3008_channel1.value
        analog_value_channel0=analog_value_channel0*1024
        sum_=sum_+analog_value_channel0
    
    analog_value_channel0=sum_/5000
    # Convert analog values to voltage and current for channel 0
    voltage_channel0 = analog_value_channel0 * 5.0/1024
    current_channel0 = (voltage_channel0 - 2.5) / 0.185 -.05

    # Convert analog values to voltage and current for channel 1
    #voltage_channel1 = analog_value_channel1 * 5.0
    #current_channel1 = (voltage_channel1 - 2.5) / 0.185
    #in_voltage = voltage_channel1*(R1+R2)/R2;

    print("Channel 0:")
    print(f"Analog Value: {analog_value_channel0:.8f}")
    print(f"Voltage Value: {voltage_channel0:.8f}")
    print(f"Current Value: {current_channel0:.8f}")

    #print("Channel 1:")
    #print(f"Analog Value: {analog_value_channel1:.8f}")
    #print(f"Voltage Value: {voltage_channel1:.8f}")
    #print(f"final voltage Value: { in_voltage:.8f}")

    time.sleep(2)  # Wait for 1 second before reading again
