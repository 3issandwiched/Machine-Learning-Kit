import spidev
import time

# Create an SPI object
spi = spidev.SpiDev()
spi.open(0, 0)  # Use SPI bus 0, device 0

def read_adc(channel):
    # Read analog data from the specified channel (0-7)
    adc = spi.xfer2([1, (8 + channel) << 4, 0])
    data = ((adc[1] & 3) << 8) + adc[2]
    return data

try:
    while True:
        # Read analog data from CH0 (or the channel connected to your sensor)
        sensor_value = read_adc(0)
        
        # You can convert the sensor_value to a meaningful range for moisture levels
        # and add your logic here
        
        print(f"Sensor Value: {sensor_value}")
        time.sleep(1)

except KeyboardInterrupt:
    # Clean up SPI settings on exit
    spi.close()
