from gpiozero import MCP3008
import time

mcp3008_channel1 = MCP3008(channel=1, max_voltage=5.0)
R1 = 30000.0
R2 = 7500.0

while True:
    analog_value_channel1 = mcp3008_channel1.value
    voltage_channel1 = analog_value_channel1 * 5.0
    in_voltage = voltage_channel1 * (R1 + R2) / R2
    
    print("Channel 1:")
    print(f"Analog Value: {analog_value_channel1:.8f}")
    print(f"Voltage Value: {voltage_channel1:.8f}")
    print(f"Final Voltage Value: {in_voltage:.8f}")

    time.sleep(2)  # Wait for 1 second before reading again
