import RPi.GPIO as GPIO
import time

# Define the GPIO pin connected to the digital output of the MQ-2 sensor
mq2_digital_pin = 17  # Change this to the GPIO pin you're using

# Set up GPIO mode and warnings
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# Set the GPIO pin as input
GPIO.setup(mq2_digital_pin, GPIO.IN)

try:
    while True:
        # Read the digital value from the MQ-2 sensor
        mq2_digital_value = GPIO.input(mq2_digital_pin)
        print(mq2_digital_value)

        if mq2_digital_value == GPIO.HIGH:
            print("Gas detected!")
        else:
            print("No gas detected.")

        time.sleep(2)  # Adjust the delay as needed

except KeyboardInterrupt:
    GPIO.cleanup()
    print('Exiting the program.')
