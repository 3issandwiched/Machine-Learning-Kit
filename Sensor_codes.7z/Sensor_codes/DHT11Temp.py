import Adafruit_DHT
import time

# Define the DHT sensor type and GPIO pin
sensor = Adafruit_DHT.DHT11
pin = 4  # Change this to the GPIO pin you're using

try:
    while True:
        # Attempt to read the temperature and humidity from the sensor
        humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)

        # Check if the reading was successful
        if humidity is not None and temperature is not None:
            print(f'Temperature: {temperature:.1f}°C')
            print(f'Humidity: {humidity:.1f}%')
        else:
            print('Failed to retrieve data from the sensor.')

        # Wait for some time before taking the next reading
        time.sleep(2)  # You can adjust the delay as needed

except KeyboardInterrupt:
    print('Exiting the program.')
