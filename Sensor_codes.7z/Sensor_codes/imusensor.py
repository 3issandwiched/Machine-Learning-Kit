import time
import smbus
from mpu6050 import mpu6050

# Initialize the MPU6050 sensor
sensor = mpu6050(0x68)  # Use 0x68 as the address for MPU9250 on the Raspberry Pi

try:
    while True:
        # Read accelerometer and gyroscope data
        accel_data = sensor.get_accel_data()
        gyro_data = sensor.get_gyro_data()
        #mag_data=sensor.get_mag_data()
        # Print the data
        print("Accelerometer data: x={}, y={}, z={}".format(
            accel_data['x'], accel_data['y'], accel_data['z']))
        print("Gyroscope data: x={}, y={}, z={}".format(
            gyro_data['x'], gyro_data['y'], gyro_data['z']))
        #print("Gyroscope data: x={}, y={}, z={}".format(
            #mag_data['x'], mag_data['y'], mag_data['z']))

        time.sleep(1)  # Adjust the sleep time as needed

except KeyboardInterrupt:
    pass
