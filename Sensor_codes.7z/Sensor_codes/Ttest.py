print("OFF") 
x=int(Time_textbox)
y=int(Iteration_Time_textbox)
print(Time_textbox)   
print(type(Time_textbox))
print(Iteration_Time_textbox)
print(x,y)



