import spidev
import time

spi = spidev.SpiDev()
spi.open(0, 0)  # Open SPI bus 0, device 0

def read_temp():
    # Read raw data (16 bits) from the MAX6675
    raw_data = spi.xfer2([0, 0, 0, 0])
    print(raw_data)
    # Combine the raw data bytes to get the temperature value
    
    temp_raw = ((raw_data[0] << 8) | raw_data[1]) >> 2
    print(temp_raw)
    # Convert raw value to Celsius
    temp_celsius = temp_raw * 0.40
    
    return temp_celsius

try:
    while True:
        temperature = read_temp()
        print(f"Temperature: {temperature} °C")
        time.sleep(1)

except KeyboardInterrupt:
    spi.close()
    print("SPI closed")
