import RPi.GPIO as GPIO
import spidev
import time

# Set the GPIO mode to BCM
GPIO.setmode(GPIO.BCM)

# Create an SPI object
spi = spidev.SpiDev()
spi.open(0, 0)  # Use SPI bus 0, device 0

# Define the gas sensor channel (CH0 in this example)
gas_sensor_channel = 0

def read_adc(channel):
    # Read analog data from the specified channel (0-7)
    adc = spi.xfer2([1, (8 + channel) << 4, 0])
    data = ((adc[1] & 3) << 8) + adc[2]
    return data

try:
    while True:
        # Read analog data from the gas sensor
        gas_sensor_value = read_adc(gas_sensor_channel)

        # You can interpret the gas_sensor_value and add your logic here
        print(f"Gas Sensor Value: {gas_sensor_value}")

        time.sleep(1)  # Adjust the delay as needed

except KeyboardInterrupt:
    print('Exiting the program.')
finally:
    # Clean up SPI settings on exit
    spi.close()
    GPIO.cleanup()
