import RPi.GPIO as GPIO
import time

# Set the mode to use BCM numbering
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
# Set up the ACT LED pin as an output
act_led_pin = 29  # The pin number for the inbuilt LED
GPIO.setup(act_led_pin, GPIO.OUT)

try:
    while True:
        GPIO.output(act_led_pin, GPIO.HIGH)  # Turn the LED on
        time.sleep(4)
        print("OFF") 
        #print(Time_textbox)                       # Wait for 1 second
        GPIO.output(act_led_pin, GPIO.LOW)   # Turn the LED off
        time.sleep(2)
        print("ON") 
        #print(Iteration_Time_textbox)
        exit()                         # Wait for 1 second

except KeyboardInterrupt:
    GPIO.cleanup()  # Clean up GPIO configuration on exit
