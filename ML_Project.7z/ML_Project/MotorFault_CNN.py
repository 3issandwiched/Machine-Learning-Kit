#CNN
import os
import joblib

import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D, MaxPooling1D, Flatten, Dense

# Load the dataset
data = pd.read_csv('/home/pi/ML_Project/Train_Datasets/dataset_Motor Fault Detection.csv')
#data=pd.read_csv(dataset_path)
# Display the first few rows of the DataFrame
#print(data.head())

# Check if column names are correct and matching the file
#print(data.columns)
X = data[['Time (s)', ' RPM', ' Encoder Position', ' Accelerometer X',
       ' Accelerometer Y', ' Accelerometer Z', ' Gyroscope X', ' Gyroscope Y',
       ' Gyroscope Z']]
y = data[' Fault']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

window_size = 15  # Adjust this based on your desired window size

X_train_windows = np.array([X_train[i:i+window_size] for i in range(len(X_train) - window_size + 1)])
X_test_windows = np.array([X_test[i:i+window_size] for i in range(len(X_test) - window_size + 1)])
y_train_windows = y_train[window_size - 1:]
y_test_windows = y_test[window_size - 1:]

# Create the CNN model
model = Sequential([
    Conv1D(filters=32, kernel_size=5, activation='relu', input_shape=(window_size, X_train.shape[1])),
    MaxPooling1D(pool_size=2, strides=1),  # Adjust strides
    Conv1D(filters=64, kernel_size=5, activation='relu'),
    MaxPooling1D(pool_size=2, strides=1),  # Adjust strides
    Flatten(),
    Dense(128, activation='relu'),
    Dense(1, activation='sigmoid')
])

model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

# Train the model
model.fit(X_train_windows, y_train_windows, epochs=10, batch_size=32, validation_split=0.2)

# Evaluate the model
loss, accuracy = model.evaluate(X_test_windows, y_test_windows)
print(f"Test Loss: {loss:.4f}, Test Accuracy: {accuracy:.4f}")


# Save the trained model to a file in the specified directory
models_directory = '/home/pi/ML_Project/Trained_Models'
os.makedirs(models_directory, exist_ok=True)
model_filename = os.path.join(models_directory, 'Test_MotorFault_CNN.h5')
#joblib.dump(model, model_filename)

try:
    #joblib.dump(model, model_filename)
    model.save(model_filename) 
    print("Model saved successfully.")
except Exception as e:
    print("Error saving model:", e)
