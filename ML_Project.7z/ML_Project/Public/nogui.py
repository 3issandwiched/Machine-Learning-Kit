print ("hello , no GUI")
x=input("do u want to continue, yes or No")
if x=="yes":
 print("exiting ")
else :
 print("good, exiting")
