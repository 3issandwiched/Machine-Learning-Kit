import numpy as np
import pandas as pd
import joblib
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

# Create a pandas DataFrame from the provided data
data_path = '/home/pi/ML_Project/Train_Datasets/Plant Health Monitoring.csv'  # Replace with the actual path to your CSV file
df = pd.read_csv(data_path)

# Convert plant health labels to numerical values (0 for Unhealthy, 1 for Healthy)
df[' Plant Health'] = df[' Plant Health'].map({' Unhealthy': 0, ' Healthy': 1})

# Split data into features (X) and target variable (y)
X = df[['Moisture Reading (%)', ' Temperature (°C)']]
y = df[' Plant Health']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a Random Forest Classifier model
model = RandomForestClassifier(random_state=42)

# Train the model
model.fit(X_train, y_train)

# Make predictions on the test set
y_pred = model.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
classification_rep = classification_report(y_test, y_pred)
print(f"Accuracy: {accuracy}")
print("Classification Report:")
print(classification_rep)

# Use the trained model for predicting plant health
new_data = np.array([[38, 26]])  # New moisture and temperature readings
predicted_health = model.predict(new_data)
predicted_health_label = 'Healthy' if predicted_health[0] == 1 else 'Unhealthy'
print(f"Predicted Plant Health: {predicted_health_label}")



# Save the trained model to a file in the specified directory
models_directory = '/home/pi/ML_Project/Trained_Models'
os.makedirs(models_directory, exist_ok=True)
model_filename = os.path.join(models_directory, 'Test_PlantHealth_Random_Forest.pkl')
#joblib.dump(model, model_filename)

try:
    joblib.dump(model, model_filename)
    #model.save(model_filename) 
    print("Model saved successfully.")
except Exception as e:
    print("Error saving model:", e)

