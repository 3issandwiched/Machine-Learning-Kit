import os
import joblib

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.metrics import accuracy_score


data = pd.read_csv('/home/pi/ML_Project/Train_Datasets/dataset_Environmental Monitoring.csv')
#data=pd.read_csv(dataset_path)

# Remove extra whitespace around boolean values
data[' Poor air quality'] = data[' Poor air quality'].str.strip()

# Convert "True" and "False" to binary values (1 and 0)
data[' Poor air quality'] = data[' Poor air quality'].apply(lambda x: 1 if x == 'True' else 0)


X = data[['Temperature', ' Humidity', ' Gas Sensor']]
y = data[' Poor air quality']



X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a linear regression model
model = LinearRegression()

# Train the model
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)

# Calculate mean squared error
mse = mean_squared_error(y_test, y_pred)

print(f'Mean Squared Error: {mse}')


y_pred_labels = y_pred > 0.5

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred_labels)

print(f'Accuracy: {accuracy:.2f}')


# Save the trained model to a file in the specified directory
models_directory = '/home/pi/ML_Project/Trained_Models'
os.makedirs(models_directory, exist_ok=True)
model_filename = os.path.join(models_directory, 'Test_EnvM_Linear_Reg.pkl')
#joblib.dump(model, model_filename)

try:
    joblib.dump(model, model_filename)
    print("Model saved successfully.")
except Exception as e:
    print("Error saving model:", e)
