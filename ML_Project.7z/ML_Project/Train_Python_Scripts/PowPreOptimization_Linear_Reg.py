import os
import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# Read data from CSV file into a pandas DataFrame
data_path = '/home/pi/ML_Project/Train_Datasets/Power Consumption Prediction.csv'  # Replace with the actual path to your CSV file
df = pd.read_csv(data_path)

# Split data into features (X) and target variable (y)
X = df[['Voltage', ' Current']]
y = df[' Power_Consumption']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a Linear Regression model
model = LinearRegression()

# Train the model
model.fit(X_train, y_train)

# Make predictions on the test set
y_pred = model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
print(f"Root Mean Squared Error: {rmse}")

# Use the trained model for predicting power consumption
new_data = np.array([[225, 1.8]])  # New voltage and current readings
predicted_power = model.predict(new_data)
print(f"Predicted Power Consumption: {predicted_power[0]}")


# Save the trained model to a file in the specified directory
models_directory = '/home/pi/ML_Project/Trained_Models'
os.makedirs(models_directory, exist_ok=True)
model_filename = os.path.join(models_directory, 'Test_PowPreOptimization_Linear_Reg.pkl')
#joblib.dump(model, model_filename)

try:
    joblib.dump(model, model_filename)
    #model.save(model_filename) 
    print("Model saved successfully.")
except Exception as e:
    print("Error saving model:", e)
