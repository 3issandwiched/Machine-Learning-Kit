import os
import joblib


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# Load the dataset
data = pd.read_csv('/home/pi/ML_Project/Train_Datasets/dataset_Environmental Monitoring.csv')
#data=pd.read_csv(dataset_path)

# Display the first few rows of the DataFrame
#print(data.head())

# Check if column names are correct and matching the file
#print(data.columns)

#print(data.columns == ['Temperature', 'Humidity', 'Gas Sensor', 'Poor air quality'])

# Split the data into features and labels
X = data[['Temperature', ' Humidity', ' Gas Sensor']]
y = data[' Poor air quality']


# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


#print(y_train)
# Create and train a logistic regression model
model = LogisticRegression()
model.fit(X_train, y_train)

# Make predictions on the test set
#print(X_test)
#print(y_test)
y_pred = model.predict(X_test)
#print(y_pred)
#print(y_test)
# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)


# Save the trained model to a file in the specified directory
models_directory = '/home/pi/ML_Project/Trained_Models'
os.makedirs(models_directory, exist_ok=True)
model_filename = os.path.join(models_directory, 'Test_EnvM_Log_Reg.pkl')
#joblib.dump(model, model_filename)

try:
    joblib.dump(model, model_filename)
    print("Model saved successfully.")
except Exception as e:
    print("Error saving model:", e)
