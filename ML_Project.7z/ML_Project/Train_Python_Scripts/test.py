print("Script is running!")

