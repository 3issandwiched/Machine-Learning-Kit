import pandas as pd

# Read the CSV file into a DataFrame
df = pd.read_csv('/home/pi/ML_Project/Test_Datasets/Altitude Estimation.csv')

# Remove the desired column (replace 'column_name' with the actual column name or index)
df = df.drop(' Altitude (meters)', axis=1)  # If you know the column name
# OR
# df = df.drop(df.columns[column_index], axis=1)  # If you know the column index

# Save the updated DataFrame to a new CSV file
df.to_csv('/home/pi/ML_Project/Test_Datasets/Altitude Estimation.csv', index=False)
