import os
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, confusion_matrix

def load_dataset(dataset_path):
    return pd.read_csv(dataset_path)

def preprocess_data(data):
    X = data[['Temperature',' Humidity', ' Gas Sensor']]
    y = data[' Poor air quality']
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    return X_scaled, y

def train_decision_tree(X_train, y_train):
    param_grid = {'criterion': ['gini', 'entropy'], 'max_depth': [None, 10, 20, 30]}
    classifier = GridSearchCV(DecisionTreeClassifier(random_state=42), param_grid, cv=5)
    classifier.fit(X_train, y_train)
    return classifier

def main():
    #dataset_path = '/home/pi/ML_Project/Train_Datasets/dataset_Environmental Monitoring.csv'
    #dataset_path=dataset_path
    data = load_dataset(dataset_path)

    X_scaled, y = preprocess_data(data)
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    classifier = train_decision_tree(X_train, y_train)

    y_pred = classifier.predict(X_test)

    print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
    print("Classification Report:\n", classification_report(y_test, y_pred))

    models_directory = '/home/pi/ML_Project/Trained_Models'
    os.makedirs(models_directory, exist_ok=True)
    model_filename = os.path.join(models_directory, 'Test_EnvM_Decision_Tree.pkl')

    try:
        joblib.dump(classifier, model_filename)
        print("Model saved successfully.")
    except Exception as e:
        print("Error saving model:", e)

if __name__ == "__main__":
    main()
