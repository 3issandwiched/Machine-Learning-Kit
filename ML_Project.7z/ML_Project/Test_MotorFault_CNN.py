import joblib
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import StandardScaler

# Load the saved CNN model
model_filename = '/home/pi/ML_Project/Trained_Models/Test_MotorFault_CNN.h5'
loaded_model = tf.keras.models.load_model(model_filename)

# Load the new dataset for testing
new_data = pd.read_csv('/home/pi/ML_Project/Test_Datasets/dataset_Motor Fault Detection.csv')  # Replace with the path to your new dataset
#new_data=pd.read_csv(dataset_path)
# Preprocess the new data to create windows (similar to training data preprocessing)
window_size = 15  # Adjust this based on your desired window size
X_new_windows = np.array([new_data[i:i+window_size].values for i in range(len(new_data) - window_size + 1)])

# Normalize the new data
scaler = StandardScaler()
X_new_scaled = scaler.fit_transform(X_new_windows.reshape(-1, X_new_windows.shape[-1]))
X_new_scaled = X_new_scaled.reshape(X_new_windows.shape)
X_new_scaled = X_new_scaled[:, :, :9] 
# Make predictions using the loaded CNN model
y_pred_prob_new = loaded_model.predict(X_new_scaled)
y_pred_new = (y_pred_prob_new > 0.5).astype(int)  # Convert probabilities to binary labels (0 or 1)

# Now you can work with y_pred_new, which contains the predicted labels for the new data
print(y_pred_new)
