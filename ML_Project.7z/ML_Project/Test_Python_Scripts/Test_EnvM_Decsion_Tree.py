import os
import joblib
import pandas as pd
from sklearn.preprocessing import StandardScaler

# Load the saved Decision Tree classifier model
model_filename = '/home/pi/ML_Project/Trained_Models/Test_EnvM_Decsion_Tree.pkl'
loaded_classifier = joblib.load(model_filename)

# Load the new dataset for testing
new_data = pd.read_csv('/home/pi/ML_Project/Test_Datasets/dataset_Environmental Monitoring.csv')  # Replace with the path to your new dataset
#new_data=pd.read_csv(dataset_path)
# Preprocess the new data and standardize the feature values
scaler = StandardScaler()
X_new = new_data[['Temperature', ' Humidity', ' Gas Sensor']]
X_new_scaled = scaler.fit_transform(X_new)

# Make predictions using the loaded Decision Tree classifier model
y_pred_new = loaded_classifier.predict(X_new_scaled)

# Create a DataFrame to display input data and predicted labels side by side
result_df = pd.DataFrame({'Input Data': X_new.values.tolist(), 'Predicted Labels': y_pred_new})

# Save the result to a CSV file
#result_csv_filename = 'predicted_results.csv'
#result_df.to_csv(result_csv_filename, index=False)




# Create a DataFrame with the original input columns and the predicted output
output_df = new_data.copy()
output_df['Predicted Output'] = y_pred_new

# Save the DataFrame as a CSV file
output_csv_path = '/home/pi/ML_Project/Predicted_Outputs/EnvM_Decsion_Tree.csv'
output_df.to_csv(output_csv_path, index=False)

#print(output_df.to_csv(index=False))  # Print the CSV data to stdout


# Print the DataFrame
print(result_df)
