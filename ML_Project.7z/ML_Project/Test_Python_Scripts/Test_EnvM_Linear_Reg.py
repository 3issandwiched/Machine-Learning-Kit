import joblib
import pandas as pd

# Load the saved linear regression model
model_filename = '/home/pi/ML_Project/Trained_Models/Test_EnvM_Linear_Reg.pkl'
loaded_model = joblib.load(model_filename)

# Load the new dataset for testing
new_data = pd.read_csv('/home/pi/ML_Project/Test_Datasets/dataset_Environmental Monitoring.csv')  # Replace with the path to your new dataset
#new_data=pd.read_csv(dataset_path)
# Preprocess the new data (similar to how you preprocessed the training data)
# For example, extract the features X_new and make predictions using the loaded model
X_new = new_data[['Temperature', ' Humidity', ' Gas Sensor']]
y_pred_new = loaded_model.predict(X_new)

# Now you can work with y_pred_new, which contains the predicted labels for the new data
#print(y_pred_new)

# Create a DataFrame with the original input columns and the predicted output
output_df = new_data.copy()
output_df['Predicted Output'] = y_pred_new

# Save the DataFrame as a CSV file
output_csv_path = '/home/pi/ML_Project/Predicted_Outputs/EnvM_Linear_Reg.csv'
output_df.to_csv(output_csv_path, index=False)

print(output_df.to_csv(index=False))  # Print the CSV data to stdout
