#Long Term Short Memory
import os
import joblib

import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import LearningRateScheduler

# Load the dataset
data=pd.read_csv('/home/pi/ML_Project/Train_Datasets/dataset_Motor Fault Detection.csv')
#data=pd.read_csv(dataset_path)
# Display the first few rows of the DataFrame
#print(data.head())

# Check if column names are correct and matching the file
#print(data.columns)
X = data[['Time (s)', ' RPM', ' Encoder Position', ' Accelerometer X',
       ' Accelerometer Y', ' Accelerometer Z', ' Gyroscope X', ' Gyroscope Y',
       ' Gyroscope Z']]
y = data[' Fault']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

window_size = 15  # Adjust this based on your desired window size

X_train_windows = np.array([X_train[i:i+window_size] for i in range(len(X_train) - window_size + 1)])
X_test_windows = np.array([X_test[i:i+window_size] for i in range(len(X_test) - window_size + 1)])
y_train_windows = y_train[window_size - 1:]
y_test_windows = y_test[window_size - 1:]
# ... (same code as before)

# Normalize the data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_windows.reshape(-1, X_train_windows.shape[-1]))
X_test_scaled = scaler.transform(X_test_windows.reshape(-1, X_test_windows.shape[-1]))

X_train_scaled = X_train_scaled.reshape(X_train_windows.shape)
X_test_scaled = X_test_scaled.reshape(X_test_windows.shape)

# Create the LTSM model
model = Sequential([
    LSTM(64, input_shape=(window_size, X_train.shape[1]), return_sequences=True),
    Dropout(0.2),
    LSTM(64, return_sequences=True),
    Dropout(0.2),
    LSTM(64),
    Dropout(0.2),
    Dense(1, activation='sigmoid')
])

model.compile(loss='binary_crossentropy', optimizer=Adam(learning_rate=0.001), metrics=['accuracy'])

# Learning Rate Schedule
def lr_schedule(epoch, lr):
    if epoch < 5:
        return lr
    else:
        return lr * 0.1

lr_scheduler = LearningRateScheduler(lr_schedule)

# Train the model
model.fit(X_train_scaled, y_train_windows, epochs=10, batch_size=32, callbacks=[lr_scheduler], validation_split=0.2)

# Evaluate the model
loss, accuracy = model.evaluate(X_test_scaled, y_test_windows)
print(f"Test Loss: {loss:.4f}, Test Accuracy: {accuracy:.4f}")


models_directory = '/home/pi/ML_Project/Trained_Models'
os.makedirs(models_directory, exist_ok=True)
model_filename = os.path.join(models_directory, 'Test_MotorFault_LTSM.h5')
#joblib.dump(model, model_filename)

try:
   # joblib.dump(model, model_filename)
    model.save(model_filename)
    print("Model saved successfully.")
except Exception as e:
    print("Error saving model:", e)
